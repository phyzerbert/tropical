<?php $__env->startSection('content'); ?>
    <div class="bg-body-light">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                <h1 class="flex-sm-fill font-size-h2 font-w400 mt-2 mb-0 mb-sm-2"><i class="nav-main-link-icon si si-present"></i> <?php echo e(__('page.product_management')); ?></h1>
                <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><i class="nav-main-link-icon si si-home"></i></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('page.product_management')); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="clearfix">
            <form action="" class="form-inline float-left">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control form-control-sm" style="width: 200px;" name="keyword" value="<?php echo e($keyword); ?>" placeholder="<?php echo e(__('page.search')); ?>...">
                <button type="submit" class="btn btn-sm btn-primary ml-2"><i class="fa fa-search"></i> <?php echo e(__('page.search')); ?></button>
            </form>
            
            <button type="button" class="btn btn-success btn-sm float-right" id="btn-add"><i class="fa fa-plus"></i> <?php echo e(__('page.add_new')); ?></button>
        </div>
        <hr />    
        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3">
                    <div class="block block-rounded block-link-pop">
                        <div class="p-3">                                
                            <img class="img-fluid" height="300" src="<?php if($item->image): ?><?php echo e(asset($item->image)); ?><?php else: ?><?php echo e(asset('images/no-image.jpg')); ?><?php endif; ?>" alt="">
                        </div>
                        <div class="block-content">
                            <h4 class="mb-1"><?php echo e($item->code); ?></h4>
                            <p class="font-size-sm description" title="<?php echo e($item->description); ?>">
                                <?php echo e($item->description); ?>

                            </p>
                        </div>
                        <div class="block-content block-content-full bg-body-light">
                            <div class="row no-gutters font-size-sm text-center">
                                <div class="col-6">
                                    <button type="button" data-id="<?php echo e($item->id); ?>" data-code="<?php echo e($item->code); ?>" data-description="<?php echo e($item->description); ?>" class="btn btn-sm btn-outline-primary btn-edit" style="min-width: 85px">
                                        <i class="fa fa-fw fa-edit mr-1"></i> <?php echo e(__('page.edit')); ?>

                                    </button>
                                </div>
                                <div class="col-6">
                                    <a href="<?php echo e(route('product.delete', $item->id)); ?>" class="btn btn-sm btn-outline-danger" style="min-width: 85px">
                                        <i class="fa fa-fw fa-times mr-1"></i> <?php echo e(__('page.delete')); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </div>
        <div class="row">
            <div class="col-12">
                <div class="clearfix mt-2">
                    <div class="float-left" style="margin: 0;">
                        <p><?php echo e(__('page.total')); ?> <strong style="color: red"><?php echo e($data->total()); ?></strong> <?php echo e(__('page.items')); ?></p>
                    </div>
                    <div class="float-right" style="margin: 0;">
                        <?php echo $data->appends(['keyword' => $keyword])->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- The Modal -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('page.add_product')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="<?php echo e(route('product.create')); ?>" id="create_form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.code')); ?></label>
                            <input class="form-control code" type="text" name="code" placeholder="<?php echo e(__('page.code')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.description')); ?></label>
                            <input class="form-control description" type="text" name="description" placeholder="<?php echo e(__('page.description')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.image')); ?></label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" data-toggle="custom-file-input" name="image" accept="image/*">
                                <label class="custom-file-label" for="example-file-input-custom">Choose file</label>
                            </div>
                        </div>
                    </div>    
                    <div class="modal-footer">
                        <button type="submit" id="btn_create" class="btn btn-primary btn-submit"><i class="fa fa-check mg-r-10"></i>&nbsp;<?php echo e(__('page.save')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times mg-r-10"></i>&nbsp;<?php echo e(__('page.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('page.edit_product')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="<?php echo e(route('product.edit')); ?>" id="edit_form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" class="id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.code')); ?></label>
                            <input class="form-control code" type="text" name="code" placeholder="<?php echo e(__('page.code')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.description')); ?></label>
                            <input class="form-control description" type="text" name="description" placeholder="<?php echo e(__('page.description')); ?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('page.image')); ?></label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" data-toggle="custom-file-input" name="image" accept="image/*">
                                <label class="custom-file-label" for="example-file-input-custom">Choose file</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="btn_update" class="btn btn-primary btn-submit"><i class="fa fa-check mg-r-10"></i>&nbsp;<?php echo e(__('page.save')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times mg-r-10"></i>&nbsp;<?php echo e(__('page.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $("#btn-add").click(function(){
                $("#create_form input.form-control").val('');
                $("#addModal").modal();
            });

            $(".btn-edit").click(function(){
                let id = $(this).data("id");
                let code = $(this).data("code");
                let description = $(this).data("description");
                $("#edit_form input.form-control").val('');
                $("#editModal .id").val(id);
                $("#editModal .code").val(code);
                $("#editModal .description").val(description);
                $("#editModal").modal();
            });

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Aug\TropicalGida\TropicalGida\resources\views/product/index.blade.php ENDPATH**/ ?>