<?php $__env->startSection('content'); ?>
    <div class="bg-body-light">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                <h1 class="flex-sm-fill font-size-h2 font-w400 mt-2 mb-0 mb-sm-2"><i class="nav-main-link-icon si si-cloud-upload"></i> <?php echo e(__('page.container_load')); ?></h1>
                <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><i class="nav-main-link-icon si si-home"></i></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('page.container_load')); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="block block-rounded block-bordered">
            <div class="block-header block-header-default justify-content-end">
                <a href="<?php echo e(route('container.create')); ?>" class="btn btn-success btn-sm float-right" id="btn-add"><i class="fa fa-plus"></i> <?php echo e(__('page.add_new')); ?></a>
            </div>
            <div class="block-content block-content-full">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered table-vcenter">
                        <thead class="thead-light">
                            <tr>
                                <td>#</td>
                                <td>IDENTIFICACION O NIT</td>
                                <td>PRECINTO</td>
                                <td>CONTENEDOR</td>
                                <td>TEMPERATURA</td>
                                <td>DAMPER</td>
                                <td>BOOKING</td>
                                <td>PUERTO DE DESTINO</td>
                                <td>FECHA</td>
                                <td>EMBARCADERO</td>
                                <td>TIPO DE MERCANCIA</td>
                                <td>AGENCIA ADUANERA</td>
                                <td>EMPRESA O PERSONA NATURAL</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                    <td><?php echo e($item->proforma->reference_no); ?></td>
                                    <td><?php echo e($item->contenedor); ?></td>
                                    <td><?php echo e($item->precinto); ?></td>
                                    <td><?php echo e($item->temperatura); ?></td>
                                    <td><?php echo e($item->damper); ?></td>
                                    <td><?php echo e($item->booking); ?></td>
                                    <td><?php echo e($item->port_of_discharge); ?></td>
                                    <td><?php echo e($item->fetcha); ?></td>
                                    <td><?php echo e($item->embarcadero); ?></td>
                                    <td><?php echo e($item->tipo_de_mercancia); ?></td>
                                    <td><?php echo e($item->agencia_aduanera); ?></td>
                                    <td><?php echo e($item->company_or_person); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                </div>                 
            </div>
        </div>
    </div>

    <div class="modal fade" id="addModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('page.container_load')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="" id="create_form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        
                        
                    </div>    
                    <div class="modal-footer">
                        <button type="submit" id="btn_create" class="btn btn-primary btn-submit"><i class="fa fa-check"></i>&nbsp;<?php echo e(__('page.save')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;<?php echo e(__('page.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $("#btn-add").click(function(){
                $("#addModal").modal();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Aug\TropicalGida\TropicalGida\resources\views/container/index.blade.php ENDPATH**/ ?>