<?php $__env->startSection('content'); ?>
    <div class="block block-transparent block-rounded w-100 mb-0 overflow-hidden">
        <div class="block-content block-content-full px-lg-4 px-xl-5 py-6 bg-white">
            <div class="mb-2 text-center">
                <a class="link-fx font-w700 font-size-h1" href="<?php echo e(route('home')); ?>">
                    <span class="text-dark">TROPICAL</span><span class="text-primary">GIDA</span>
                </a>
                <p class="text-uppercase font-w700 font-size-sm text-muted">Sign In</p>
            </div>
            <form class="js-validation-signin" action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group mt-4">
                    <div class="input-group">
                        <input type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="login-username" name="name" placeholder="Username" required autocomplete="name" autofocus />
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fa fa-user-circle"></i>
                            </span>
                        </div>
                    </div>
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group mt-5">
                    <div class="input-group">
                        <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="login-password" name="password" placeholder="Password" required autocomplete="current-password" />
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fa fa-asterisk"></i>
                            </span>
                        </div>
                    </div>
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group mt-4 d-sm-flex justify-content-sm-between align-items-sm-center text-center text-sm-left">
                    <div class="custom-control custom-checkbox custom-control-primary">
                        <input type="checkbox" class="custom-control-input" id="login-remember-me" name="remember"  <?php echo e(old('remember') ? 'checked' : ''); ?> />
                        <label class="custom-control-label" for="login-remember-me">Remember Me</label>
                    </div>
                </div>
                <div class="form-group text-center mt-4">
                    <button type="submit" class="btn btn-hero-primary">
                        <i class="fa fa-fw fa-sign-in-alt mr-1"></i> Sign In
                    </button>
                </div>
            </form>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Aug\TropicalGida\TropicalGida\resources\views/auth/login.blade.php ENDPATH**/ ?>