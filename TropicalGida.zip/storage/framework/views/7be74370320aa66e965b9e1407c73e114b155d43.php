<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/js/plugins/jquery-ui/jquery-ui.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('master/js/plugins/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.css')); ?>" rel="stylesheet">  
    <link rel="stylesheet" href="<?php echo e(asset('master/js/plugins/imageviewer/css/jquery.verySimpleImageViewer.css')); ?>">
    <style>
        #image_preview {
            max-width: 600px;
            height: 600px;
        }
        .image_viewer_inner_container {
            width: 100% !important;
        }
    </style>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="bg-body-light">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                <h1 class="flex-sm-fill font-size-h2 font-w400 mt-2 mb-0 mb-sm-2"><i class="nav-main-link-icon si si-people"></i> <?php echo e(__('page.payment_list')); ?></h1>
                <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><i class="nav-main-link-icon si si-home"></i></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('page.payment_list')); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="block block-rounded block-bordered">
            <div class="block-content block-content-full">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-colored">
                            <tr class="bg-blue">
                                <th style="width:40px;">#</th>
                                <th><?php echo e(__('page.date')); ?></th>
                                <th><?php echo e(__('page.reference_no')); ?></th>
                                <th><?php echo e(__('page.amount')); ?></th> 
                                <th><?php echo e(__('page.note')); ?></th>
                                <th><?php echo e(__('page.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>                                
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td class="date"><?php echo e(date('Y-m-d H:i', strtotime($item->timestamp))); ?></td>
                                    <td class="reference_no"><?php echo e($item->reference_no); ?></td>
                                    <td class="amount" data-value="<?php echo e($item->amount); ?>"><?php echo e(number_format($item->amount)); ?></td>
                                    <td class="" data-path="<?php echo e($item->attachment); ?>">
                                        <span class="tx-info note"><?php echo e($item->note); ?></span>&nbsp;
                                        <?php if($item->attachment != ""): ?>
                                            <a href="#" class="attachment" data-value="<?php echo e(asset($item->attachment)); ?>"><i class="fa fa-paperclip"></i></a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-primary js-tooltip-enabled btn-edit" data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" title="" data-original-title="<?php echo e(__('page.edit')); ?>">
                                                <i class="fa fa-pencil-alt"></i>
                                            </button>
                                            <a href="<?php echo e(route('payment.delete', $item->id)); ?>" class="btn btn-sm btn-primary js-tooltip-enabled" data-toggle="tooltip" title="" data-original-title="<?php echo e(__('page.delete')); ?>" onclick="return window.confirm('<?php echo e(__('page.are_you_sure')); ?>')">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="text-right">
                        <?php if($type == 'invoice'): ?>
                            <a href="<?php echo e(route('invoice.create')); ?>" class="btn btn-oblong btn-primary mr-3"><i class="fa fa-plus"></i>  <?php echo e(__('page.add_invoice')); ?></a>                                       
                            <a href="<?php echo e(route('invoice.index')); ?>" class="btn btn-oblong btn-success"><i class="fa fa-list"></i>  <?php echo e(__('page.invoices')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>                               
            </div>
        </div>
    </div>

    <!-- The Modal -->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('page.edit_payment')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="<?php echo e(route('payment.edit')); ?>" id="edit_form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" class="id">
                    <div class="modal-body">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.date')); ?></label>
                                <input class="form-control date" type="text" name="date" autocomplete="off" value="<?php echo e(date('Y-m-d H:i')); ?>" placeholder="<?php echo e(__('page.date')); ?>">
                            </div>                        
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.reference_no')); ?></label>
                                <input class="form-control reference_no" type="text" name="reference_no" placeholder="<?php echo e(__('page.reference_number')); ?>">
                            </div>                                                
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.amount')); ?></label>
                                <input class="form-control amount" type="text" name="amount" placeholder="<?php echo e(__('page.amount')); ?>">
                            </div>                                               
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.attachment')); ?></label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" data-toggle="custom-file-input" name="attachment" accept="image/*">
                                    <label class="custom-file-label" for="example-file-input-custom">Choose file</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label"><?php echo e(__('page.note')); ?></label>
                                <textarea class="form-control note" type="text" name="note" placeholder="<?php echo e(__('page.note')); ?>"></textarea>
                            </div>
                    </div>  
                    <div class="modal-footer">
                        <button type="submit" id="btn_update" class="btn btn-primary btn-submit"><i class="fa fa-check mg-r-10"></i>&nbsp;<?php echo e(__('page.save')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times mg-r-10"></i>&nbsp;<?php echo e(__('page.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="attachModal">
        <div class="modal-dialog" style="margin-top:17vh">
            <div class="modal-content">
                <div id="image_preview"></div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('master/js/plugins/jquery-ui/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('master/js/plugins/jquery-ui/timepicker/jquery-ui-timepicker-addon.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/js/plugins/imageviewer/js/jquery.verySimpleImageViewer.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $("#edit_form input.date").datetimepicker({
                dateFormat: 'yy-mm-dd',
            });

            $(".btn-edit").click(function(){
                let id = $(this).data("id");
                let date = $(this).parents('tr').find(".date").text().trim();
                let reference_no = $(this).parents('tr').find(".reference_no").text().trim();
                let amount = $(this).parents('tr').find(".amount").data('value');
                let note = $(this).parents('tr').find(".note").text().trim();
                $("#editModal input.form-control").val('');
                $("#editModal .id").val(id);
                $("#editModal .date").val(date);
                $("#editModal .reference_no").val(reference_no);
                $("#editModal .amount").val(amount);
                $("#editModal .note").val(note);
                $("#editModal").modal();
            });

            $(".attachment").click(function(e){
                e.preventDefault();
                let path = $(this).data('value');
                $("#image_preview").html('')
                $("#image_preview").verySimpleImageViewer({
                    imageSource: path,
                    frame: ['100%', '100%'],
                    maxZoom: '900%',
                    zoomFactor: '10%',
                    mouse: true,
                    keyboard: true,
                    toolbar: true,
                });
                $("#attachModal").modal();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Aug\TropicalGida\TropicalGida\resources\views/payment/index.blade.php ENDPATH**/ ?>