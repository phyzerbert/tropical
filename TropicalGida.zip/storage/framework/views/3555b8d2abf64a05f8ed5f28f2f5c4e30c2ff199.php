<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('master/js/plugins/jquery-ui/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('master/js/plugins/select2/css/select2.min.css')); ?>">
    <script src="<?php echo e(asset('master/js/plugins/vuejs/vue.js')); ?>"></script>
    <script src="<?php echo e(asset('master/js/plugins/vuejs/axios.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="bg-body-light">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                <h1 class="flex-sm-fill font-size-h2 font-w400 mt-2 mb-0 mb-sm-2"><i class="far fa-file-alt"></i> <?php echo e(__('page.invoice_detail')); ?></h1>
                <nav class="flex-sm-00-auto ml-sm-3" aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><i class="si si-home"></i></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('page.invoice_detail')); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="content content-boxed">
        <div class="block block-fx-shadow">
            <div class="block-header block-header-default">
                <h3 class="block-title py-3" style="font-size:35px">INVOICE : <?php echo e($invoice->reference_no); ?></h3>
            </div>
            <div class="block-content">
                <div class="p-sm-4 p-xl-6">
                    <div class="row mb-5">
                        <div class="col-md-6">
                            <h4><?php echo e(__('page.issue_date')); ?> : <?php echo e($invoice->issue_date); ?></h4>
                            <h4><?php echo e(__('page.due_date')); ?> : <?php echo e($invoice->due_date); ?></h4>
                            <h4><?php echo e(__('page.customers_vat')); ?> : <?php echo e($invoice->customers_vat); ?></h4>
                            <h4><?php echo e(__('page.delivery_date')); ?> : <?php echo e($invoice->delivery_date); ?></h4>
                        </div>
                        <div class="col-md-6">
                            <h4><?php echo e(__('page.concerning_week')); ?> : <?php echo e($invoice->concerning_week); ?></h4>
                            <h4><?php echo e(__('page.shipment')); ?> : <?php echo e($invoice->shipment); ?></h4>
                            <h4><?php echo e(__('page.vessel')); ?> : <?php echo e($invoice->vessel); ?></h4>
                            <h4><?php echo e(__('page.port_of_discharge')); ?> : <?php echo e($invoice->port_of_discharge); ?></h4>
                            <h4><?php echo e(__('page.origin')); ?> : <?php echo e($invoice->origin); ?></h4>
                        </div>
                    </div>
                    <div class="table-responsive push">
                        <table class="table table-bordered">
                            <thead class="bg-body">
                                <tr>
                                    <th class="text-center" style="width: 60px;"></th>
                                    <th><?php echo e(__('page.product')); ?></th>
                                    <th class="text-right" style="width: 90px;"><?php echo e(__('page.quantity')); ?></th>
                                    <th class="text-right" style="width: 120px;"><?php echo e(__('page.price')); ?></th>
                                    <th class="text-right"><?php echo e(__('page.amount')); ?></th>
                                    <th class="text-right"><?php echo e(__('page.surcharge_reduction')); ?></th>
                                    <th class="text-right" style="width: 120px;"><?php echo e(__('page.total_amount')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $footer_quantity = $footer_amount = 0;
                                ?>
                                <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $footer_quantity += $item->quantity;
                                        $footer_amount += $item->total_amount;
                                    ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                                        <td>
                                            <p class="font-w600 mb-1"><?php echo e($item->product->code); ?></p>
                                            <div class="text-muted"><?php echo e($item->product->description); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge badge-pill badge-primary"><?php echo e($item->quantity); ?></span>
                                        </td>
                                        <td class="text-right"><?php echo e($item->price); ?></td>
                                        <td class="text-right"><?php echo e($item->amount); ?></td>
                                        <td class="text-right"><?php echo e($item->surcharge_reduction); ?></td>
                                        <td class="text-right"><?php echo e($item->total_amount); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="2" class="text-right"><?php echo e(__('page.total')); ?> : </td>
                                    <td class="total_quantity"><?php echo e($footer_quantity); ?></td>
                                    <td colspan="3" align="right">Total Excluding VAT</td>
                                    <td colspan="2" class="total_excluding_vat"><?php echo e($footer_amount); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="6" align="right">V.A.T</td>
                                    <td colspan="2"><?php echo e($invoice->vat_amount); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="6" align="right">Total Including VAT</td>
                                    <td colspan="2"><?php echo e($invoice->total_to_pay); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="6" align="right">Total To Pay</td>
                                    <td colspan="2">
                                        <?php echo e($invoice->total_to_pay); ?>

                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="clearfix">
                        <a href="<?php echo e(route('invoice.index')); ?>" class="btn btn-primary float-right"><i class="far fa-file-alt"></i> <?php echo e(__('page.invoices')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\2019-Aug\TropicalGida\TropicalGida\resources\views/invoice/detail.blade.php ENDPATH**/ ?>